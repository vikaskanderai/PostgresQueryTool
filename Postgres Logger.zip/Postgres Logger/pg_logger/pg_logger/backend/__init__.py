"""Backend package - Database and network logic."""
