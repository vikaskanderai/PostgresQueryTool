"""Frontend package - UI components and styling."""
